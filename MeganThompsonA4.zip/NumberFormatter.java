/** 
 * Title: Assignment 4
 * Semester: COP3337 � Fall 2019
 * @author Megan Jane Thompson
 *
 * I affirm that this program is entirely my own work
 * and none of it is the work of any other person.
 * 
 * This program provides and interface to format numbers.
*/

public interface NumberFormatter { 
  String format (int n);                          //method to intake and integer and return a String
}